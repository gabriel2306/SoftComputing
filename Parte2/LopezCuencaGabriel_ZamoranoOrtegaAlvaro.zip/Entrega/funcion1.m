function [minimo] = funcion1(vector)
    minimo = sum(vector.^2);
end

    
    